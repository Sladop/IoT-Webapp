class MorseController {

    constructor() {
    }

}