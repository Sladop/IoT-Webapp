class MorseController {

    constructor(track) {
        this.isActive = false;
        this.track = track;
    }

    toggleTorch() {
        this.track.applyConstraints({
            advanced: [{ torch: true }]
        });
    }

    getTrack() {
        return this.isActive;
    }
}